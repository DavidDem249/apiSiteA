<?php

	return[
	    'v2-checkbox' => env('RECAPTCHA_SECRET_KEY'),
	];